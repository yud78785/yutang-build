//go:build windows

package main

import (
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"syscall"
	"testing"
	"time"
	"unicode/utf16"
	"unsafe"
)

func TestGuardHelper(t *testing.T) {
	switch os.Getenv("YT_JOB_GUARD_HELPER") {
	case "owner":
		dir := os.Getenv("YT_JOB_GUARD_DIR")
		// Match the browser controller: the Win32 environment block passed to
		// CreateProcess must exclude Windows pseudo-variables such as =C:=.
		var env []string
		for _, entry := range os.Environ() {
			if !strings.HasPrefix(entry, "=") && !strings.HasPrefix(strings.ToUpper(entry), "YT_JOB_GUARD_") {
				env = append(env, entry)
			}
		}
		env = append(env, "YT_JOB_GUARD_HELPER=child", "YT_JOB_GUARD_DIR="+dir)
		p, err := startJobGuardedProcess(os.Args[0], []string{"-test.run=^TestGuardHelper$"}, dir, env)
		if err != nil {
			_ = os.WriteFile(filepath.Join(dir, "owner_failure"), []byte(err.Error()), 0600)
			fmt.Fprintln(os.Stderr, "owner launch:", err)
			os.Exit(31)
		}
		for i := 0; i < 100; i++ {
			if _, err := os.Stat(filepath.Join(dir, "owner_exit")); err == nil {
				// Intentionally bypass all defers/Stop/Wait and exit abruptly.
				// The OS must close our un-inherited job handle.
				os.Exit(0)
			}
			time.Sleep(50 * time.Millisecond)
		}
		_ = p.KillTree()
		os.Exit(32)
	case "child":
		dir := os.Getenv("YT_JOB_GUARD_DIR")
		grandchild := exec.Command(os.Args[0], "-test.run=^TestGuardHelper$")
		grandchild.Env = append(os.Environ(), "YT_JOB_GUARD_HELPER=grandchild")
		if err := grandchild.Start(); err != nil {
			os.Exit(33)
		}
		value := fmt.Sprintf("%d\n%d\n", os.Getpid(), grandchild.Process.Pid)
		if err := os.WriteFile(filepath.Join(dir, "process_ids"), []byte(value), 0600); err != nil {
			os.Exit(34)
		}
		for {
			time.Sleep(time.Second)
		}
	case "grandchild", "sentinel":
		for {
			time.Sleep(time.Second)
		}
	}
}

func waitFile(path string, timeout time.Duration) ([]byte, error) {
	until := time.Now().Add(timeout)
	for time.Now().Before(until) {
		b, e := os.ReadFile(path)
		if e == nil && len(b) > 0 {
			return b, nil
		}
		time.Sleep(50 * time.Millisecond)
	}
	return nil, fmt.Errorf("timed out waiting for process id marker")
}

func handleForWait(pid int) (syscall.Handle, error) {
	// SYNCHRONIZE + PROCESS_QUERY_LIMITED_INFORMATION; opening a handle
	// before exiting the owner prevents PID-reuse mistakes in the test.
	return syscall.OpenProcess(0x00100000|0x00001000, false, uint32(pid))
}

func waitExited(handle syscall.Handle, waitMs uint32) bool {
	n, e := syscall.WaitForSingleObject(handle, waitMs)
	return e == nil && n == syscall.WAIT_OBJECT_0
}

func TestWindowsJobCloseKillsChildAndGrandchildButNotSibling(t *testing.T) {
	for _, mode := range []string{"host_force_killed", "host_exit_no_stop"} {
		t.Run(mode, func(t *testing.T) {
			dir := t.TempDir()
			sentinel := exec.Command(os.Args[0], "-test.run=^TestGuardHelper$")
			sentinel.Env = append(os.Environ(), "YT_JOB_GUARD_HELPER=sentinel")
			if e := sentinel.Start(); e != nil {
				t.Fatal(e)
			}
			defer func() { _ = sentinel.Process.Kill(); _ = sentinel.Wait() }()
			sentHandle, e := handleForWait(sentinel.Process.Pid)
			if e != nil {
				t.Fatal(e)
			}
			defer syscall.CloseHandle(sentHandle)

			owner := exec.Command(os.Args[0], "-test.run=^TestGuardHelper$")
			owner.Env = append(os.Environ(), "YT_JOB_GUARD_HELPER=owner", "YT_JOB_GUARD_DIR="+dir)
			if e := owner.Start(); e != nil {
				t.Fatal(e)
			}
			defer func() {
				if owner.ProcessState == nil {
					_ = owner.Process.Kill()
					_ = owner.Wait()
				}
			}()
			raw, e := waitFile(filepath.Join(dir, "process_ids"), 10*time.Second)
			if e != nil {
				t.Fatal(e)
			}
			lines := strings.Fields(string(raw))
			if len(lines) != 2 {
				t.Fatalf("expected child and grandchild process IDs, got %q", string(raw))
			}
			handles := make([]syscall.Handle, 0, 2)
			defer func() {
				for _, h := range handles {
					_ = syscall.CloseHandle(h)
				}
			}()
			for _, s := range lines {
				pid, e := strconv.Atoi(s)
				if e != nil {
					t.Fatal(e)
				}
				h, e := handleForWait(pid)
				if e != nil {
					t.Fatalf("cannot open process %d: %v", pid, e)
				}
				handles = append(handles, h)
				if waitExited(h, 0) {
					t.Fatalf("child process %d exited before owner crash", pid)
				}
			}
			if mode == "host_force_killed" {
				// This is Windows TerminateProcess(), not a cooperating Stop().
				if e := owner.Process.Kill(); e != nil {
					t.Fatal(e)
				}
				_ = owner.Wait() // A nonzero exit code is expected.
			} else {
				if e := os.WriteFile(filepath.Join(dir, "owner_exit"), []byte("exit"), 0600); e != nil {
					t.Fatal(e)
				}
				if e := owner.Wait(); e != nil {
					t.Fatalf("owner should exit without Stop: %v", e)
				}
			}
			for i, h := range handles {
				if !waitExited(h, 5000) {
					t.Errorf("job descendant #%d survived owner termination", i+1)
				}
			}
			if waitExited(sentHandle, 0) {
				t.Error("unrelated sentinel process was killed")
			}
		})
	}
}

func TestWindowsJobLimitsAndFailClosedBadAssignment(t *testing.T) {
	if unsafe.Sizeof(jobExtendedLimitInformation{}) != 144 && unsafe.Sizeof(uintptr(0)) == 8 {
		t.Fatalf("unexpected JOBOBJECT_EXTENDED_LIMIT_INFORMATION layout %d", unsafe.Sizeof(jobExtendedLimitInformation{}))
	}
	job, e := createKillOnCloseJob()
	if e != nil {
		t.Fatal(e)
	}
	defer syscall.CloseHandle(job)
	var info jobExtendedLimitInformation
	var retLen uint32
	query := syscall.NewLazyDLL("kernel32.dll").NewProc("QueryInformationJobObject")
	ok, _, callErr := query.Call(uintptr(job), jobObjectExtendedLimitInformation, uintptr(unsafe.Pointer(&info)), unsafe.Sizeof(info), uintptr(unsafe.Pointer(&retLen)))
	if ok == 0 {
		t.Fatalf("could not read effective job limits: %v", callErr)
	}
	if info.BasicLimitInformation.LimitFlags != jobObjectLimitKillOnClose {
		t.Fatalf("job flags must be kill-on-close ONLY, got %#x", info.BasicLimitInformation.LimitFlags)
	}
	if e := assignToJob(0, 0); e == nil {
		t.Fatal("invalid job/process handle unexpectedly accepted")
	}
}

func TestWindowsEnvironmentBlockIsDoubleNulTerminated(t *testing.T) {
	env, err := windowsEnvBlock([]string{`SYSTEMROOT=C:\Windows`, `PATH=C:\Windows\System32`, "YT_JOB_GUARD_HELPER=child"})
	if err != nil {
		t.Fatal(err)
	}
	if len(env) < 2 || env[len(env)-1] != 0 || env[len(env)-2] != 0 {
		t.Fatal("Windows environment is not double NUL-terminated")
	}
	contents := string(utf16.Decode(env))
	if !strings.Contains(contents, `SYSTEMROOT=C:\Windows`+"\x00") ||
		!strings.Contains(contents, "YT_JOB_GUARD_HELPER=child\x00") {
		t.Fatalf("missing NUL-separated environment entries: %q", contents)
	}
	if _, err = windowsEnvBlock([]string{"Path=one", "PATH=two"}); err == nil {
		t.Fatal("duplicate Windows environment keys should fail closed")
	}
}
