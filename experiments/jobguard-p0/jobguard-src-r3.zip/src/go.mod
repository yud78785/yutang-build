module yutang-jobguard-poc

go 1.23
