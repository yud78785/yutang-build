package main

import (
	"os"
	"runtime"
	"testing"
)

func TestGuardStartsAndWaitsForOrdinaryChild(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("Windows has its own parent-crash integration test")
	}
	dir := t.TempDir()
	p, e := startJobGuardedProcess("/bin/sh", []string{"-c", "exit 0"}, dir, os.Environ())
	if e != nil {
		t.Fatal(e)
	}
	if p.PID() <= 0 {
		t.Fatal("no process id")
	}
	if e := p.Wait(); e != nil {
		t.Fatal(e)
	}
}

func TestGuardRejectsMissingExecutable(t *testing.T) {
	if _, e := startJobGuardedProcess("", nil, t.TempDir(), os.Environ()); e == nil {
		t.Fatal("empty executable must fail")
	}
}
