//go:build windows

package main

import (
	"errors"
	"fmt"
	"os"
	"sort"
	"strings"
	"sync"
	"syscall"
	"unicode/utf16"
	"unsafe"
)

// Windows Job Object creation is deliberately fail-closed. The child is
// CREATE_SUSPENDED until the kill-on-close job is configured and assigned.
// No CREATE_BREAKAWAY_FROM_JOB or SILENT_BREAKAWAY_OK flags are used.
const (
	createSuspended                   = uint32(0x00000004)
	jobObjectExtendedLimitInformation = uintptr(9)
	jobObjectLimitKillOnClose         = uint32(0x00002000)
	stillActive                       = uint32(259)
)

type jobBasicLimitInformation struct {
	PerProcessUserTimeLimit int64
	PerJobUserTimeLimit     int64
	LimitFlags              uint32
	MinimumWorkingSetSize   uintptr
	MaximumWorkingSetSize   uintptr
	ActiveProcessLimit      uint32
	Affinity                uintptr
	PriorityClass           uint32
	SchedulingClass         uint32
}

type jobIOCounters struct {
	ReadOperationCount  uint64
	WriteOperationCount uint64
	OtherOperationCount uint64
	ReadTransferCount   uint64
	WriteTransferCount  uint64
	OtherTransferCount  uint64
}

type jobExtendedLimitInformation struct {
	BasicLimitInformation jobBasicLimitInformation
	IoInfo                jobIOCounters
	ProcessMemoryLimit    uintptr
	JobMemoryLimit        uintptr
	PeakProcessMemoryUsed uintptr
	PeakJobMemoryUsed     uintptr
}

var (
	jobKernel                    = syscall.NewLazyDLL("kernel32.dll")
	procCreateJobObject          = jobKernel.NewProc("CreateJobObjectW")
	procSetInformationJobObject  = jobKernel.NewProc("SetInformationJobObject")
	procAssignProcessToJobObject = jobKernel.NewProc("AssignProcessToJobObject")
	procResumeThread             = jobKernel.NewProc("ResumeThread")
)

func resultErr(err error) error {
	if err != nil && err != syscall.Errno(0) {
		return err
	}
	return errors.New("Win32 API returned failure")
}

func createKillOnCloseJob() (syscall.Handle, error) {
	h, _, e := procCreateJobObject.Call(0, 0)
	if h == 0 {
		return 0, fmt.Errorf("CreateJobObjectW: %w", resultErr(e))
	}
	job := syscall.Handle(h)
	info := jobExtendedLimitInformation{}
	info.BasicLimitInformation.LimitFlags = jobObjectLimitKillOnClose
	ok, _, e := procSetInformationJobObject.Call(uintptr(job), jobObjectExtendedLimitInformation,
		uintptr(unsafe.Pointer(&info)), unsafe.Sizeof(info))
	if ok == 0 {
		_ = syscall.CloseHandle(job)
		return 0, fmt.Errorf("SetInformationJobObject: %w", resultErr(e))
	}
	return job, nil
}

func assignToJob(job syscall.Handle, process syscall.Handle) error {
	ok, _, e := procAssignProcessToJobObject.Call(uintptr(job), uintptr(process))
	if ok == 0 {
		return fmt.Errorf("AssignProcessToJobObject: %w", resultErr(e))
	}
	return nil
}

func resumePrimaryThread(thread syscall.Handle) error {
	prior, _, e := procResumeThread.Call(uintptr(thread))
	if prior == uintptr(^uint32(0)) {
		return fmt.Errorf("ResumeThread: %w", resultErr(e))
	}
	// CREATE_SUSPENDED guarantees the primary thread's initial suspend count is 1.
	if prior != 1 {
		return fmt.Errorf("unexpected primary-thread suspend count %d", prior)
	}
	return nil
}

func windowsEnvBlock(env []string) ([]uint16, error) {
	values := make([]string, 0, len(env))
	seen := make(map[string]bool, len(env))
	for _, line := range env {
		if strings.IndexByte(line, 0) >= 0 || !strings.Contains(line, "=") || strings.HasPrefix(line, "=") {
			return nil, errors.New("invalid environment entry")
		}
		name, _, _ := strings.Cut(line, "=")
		upper := strings.ToUpper(name)
		if seen[upper] {
			return nil, errors.New("duplicate environment key")
		}
		seen[upper] = true
		values = append(values, line)
	}
	sort.Slice(values, func(i, j int) bool { return strings.ToUpper(values[i]) < strings.ToUpper(values[j]) })
	if len(values) == 0 {
		return []uint16{0, 0}, nil
	}
	// UTF16FromString rejects embedded NUL. A Windows environment block is
	// intentionally a UTF-16 sequence of NUL-separated key=value strings,
	// terminated by an additional NUL; encode runes directly.
	return utf16.Encode([]rune(strings.Join(values, "\x00") + "\x00\x00")), nil
}

// startJobGuardedProcess's caller MUST pass only the validated Chrome executable
// and a pinned argument list. This function does not accept shell command text.
func startJobGuardedProcess(executable string, args []string, workDir string, env []string) (*guardedBrowserProcess, error) {
	if executable == "" || workDir == "" {
		return nil, errors.New("browser executable/workdir missing")
	}
	app, err := syscall.UTF16PtrFromString(executable)
	if err != nil {
		return nil, errors.New("invalid browser executable path")
	}
	wd, err := syscall.UTF16PtrFromString(workDir)
	if err != nil {
		return nil, errors.New("invalid browser working directory")
	}
	argv := append([]string{executable}, args...)
	quoted := make([]string, 0, len(argv))
	for _, a := range argv {
		if strings.IndexByte(a, 0) >= 0 {
			return nil, errors.New("invalid browser argument")
		}
		quoted = append(quoted, syscall.EscapeArg(a))
	}
	command, err := syscall.UTF16FromString(strings.Join(quoted, " "))
	if err != nil {
		return nil, errors.New("invalid browser command line")
	}
	block, err := windowsEnvBlock(env)
	if err != nil {
		return nil, err
	}
	job, err := createKillOnCloseJob()
	if err != nil {
		return nil, fmt.Errorf("browser launch blocked: %w", err)
	}
	var pi syscall.ProcessInformation
	startup := syscall.StartupInfo{Cb: uint32(unsafe.Sizeof(syscall.StartupInfo{}))}
	// Nothing is inherited from MCP. This also prevents Chrome from inheriting
	// the Job Object handle and defeating kill-on-close when the host crashes.
	err = syscall.CreateProcess(app, &command[0], nil, nil, false,
		createSuspended|syscall.CREATE_UNICODE_ENVIRONMENT,
		&block[0], wd, &startup, &pi)
	if err != nil {
		_ = syscall.CloseHandle(job)
		return nil, fmt.Errorf("browser launch failed before resume: %w", err)
	}
	// The only path that resumes Chrome is after a successful job association.
	// On *every* error prior to resume, force termination of suspended Chrome.
	var live = false
	defer func() {
		if !live {
			_ = syscall.TerminateProcess(pi.Process, 1)
			_ = syscall.CloseHandle(job)
		}
		_ = syscall.CloseHandle(pi.Thread)
		_ = syscall.CloseHandle(pi.Process)
	}()
	if err := assignToJob(job, pi.Process); err != nil {
		return nil, fmt.Errorf("browser launch blocked: %w", err)
	}
	p, err := os.FindProcess(int(pi.ProcessId))
	if err != nil {
		return nil, fmt.Errorf("browser process handle: %w", err)
	}
	if err := resumePrimaryThread(pi.Thread); err != nil {
		_ = p.Release()
		return nil, fmt.Errorf("browser launch blocked: %w", err)
	}
	live = true
	var mu sync.Mutex
	closed := false
	closeJob := func() error {
		mu.Lock()
		defer mu.Unlock()
		if closed {
			return nil
		}
		closed = true
		return syscall.CloseHandle(job)
	}
	return &guardedBrowserProcess{
		Process: p,
		waitFunc: func() error {
			_, err := p.Wait()
			// Chrome root may exit before subprocesses; close job to kill remnants.
			closeErr := closeJob()
			if err != nil {
				return err
			}
			return closeErr
		},
		killFunc: closeJob,
	}, nil
}
