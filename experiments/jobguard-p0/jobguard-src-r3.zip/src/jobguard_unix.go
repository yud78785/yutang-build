//go:build !windows

package main

import (
	"os/exec"
	"syscall"
)

func startJobGuardedProcess(executable string, args []string, workDir string, env []string) (*guardedBrowserProcess, error) {
	cmd := exec.Command(executable, args...)
	cmd.Dir = workDir
	cmd.Env = env
	cmd.SysProcAttr = &syscall.SysProcAttr{Setpgid: true}
	if err := cmd.Start(); err != nil {
		return nil, err
	}
	p := cmd.Process
	return &guardedBrowserProcess{
		Process:  p,
		waitFunc: cmd.Wait,
		killFunc: func() error {
			err := syscall.Kill(-p.Pid, syscall.SIGKILL)
			if err == syscall.ESRCH {
				return nil
			}
			return err
		},
	}, nil
}
