package main

import (
    "errors"
    "os"
)

// guardedBrowserProcess is owned by the dedicated YuTang browser controller.
// Never copy it. On Windows the Job Object handle lives in this MCP process:
// an unexpected host exit closes the handle and terminates all job processes.
type guardedBrowserProcess struct {
    Process *os.Process
    waitFunc func() error
    killFunc func() error
}

func (p *guardedBrowserProcess) PID() int {
    if p == nil || p.Process == nil { return 0 }
    return p.Process.Pid
}
func (p *guardedBrowserProcess) Wait() error {
    if p == nil || p.waitFunc == nil { return errors.New("guarded process is unavailable") }
    return p.waitFunc()
}
func (p *guardedBrowserProcess) KillTree() error {
    if p == nil || p.killFunc == nil { return errors.New("guarded process is unavailable") }
    return p.killFunc()
}
